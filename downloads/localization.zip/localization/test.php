<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<title>Message</title>
</head>
<body>
<?php

require_once "includes/Localization.class.php";
$loc = new Localization;
$loc->setDomain("test");
$loc->setLocale("de_DE"); // change this to "jp" to see other translation
echo $loc->_("This is a test!");

//$loc->createGettextPotFor(__FILE__);
//$loc->compileAll();
?>
</body>
</html>